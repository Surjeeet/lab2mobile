import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Simple Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false, // Remove the debug tag
      home: CalculatorHomePage(),
    );
  }
}

class CalculatorHomePage extends StatefulWidget {
  @override
  _CalculatorHomePageState createState() => _CalculatorHomePageState();
}

class _CalculatorHomePageState extends State<CalculatorHomePage> {
  String display = "0";
  double result = 0;
  String? operation;
  bool newInput = false;
  List<String> history = [];

  @override
  void initState() {
    super.initState();
    _loadState();
  }

  _loadState() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      display = prefs.getString('display') ?? "0";
      history = prefs.getStringList('history') ?? [];
    });
  }

  _saveState() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('display', display);
    prefs.setStringList('history', history);
  }

  void buttonPressed(String buttonText) {
    if (buttonText == "CE") {
      setState(() {
        display = "0";
      });
    } else if (buttonText == "C") {
      setState(() {
        display = "0";
        result = 0;
        operation = null;
      });
    } else if (buttonText == "+" || buttonText == "-" || buttonText == "*" || buttonText == "/") {
      setState(() {
        result = double.parse(display);
        operation = buttonText;
        newInput = true;
      });
    } else if (buttonText == "=") {
      setState(() {
        double? num = double.tryParse(display);
        if (num != null && operation != null) {
          String previousDisplay = display;
          switch (operation) {
            case "+":
              result += num;
              break;
            case "-":
              result -= num;
              break;
            case "*":
              result *= num;
              break;
            case "/":
              if (num == 0) {
                display = "ERROR";
                return;
              }
              result /= num;
              break;
          }
          display = result.toString();
          if (display.length > 8) {
            display = "OVERFLOW";
          }
          operation = null;
          history.add("$previousDisplay = $display");
        }
        newInput = true;
      });
    } else {
      setState(() {
        if (newInput || display == "0") {
          display = buttonText;
          newInput = false;
        } else {
          display += buttonText;
        }
      });
    }
    _saveState();
  }

  Widget buildButton(String buttonText, Color color) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(2.0),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: color,
            padding: EdgeInsets.all(20.0),
          ),
          child: Text(
            buttonText,
            style: TextStyle(fontSize: 20.0, color: Colors.white),
          ),
          onPressed: () => buttonPressed(buttonText),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Simple Calculator'),
        actions: [
          IconButton(
            icon: Icon(Icons.history),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => HistoryPage(history: history),
                ),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              alignment: Alignment.bottomRight,
              color: Colors.black,
              padding: EdgeInsets.all(20.0),
              child: Text(
                display,
                style: TextStyle(fontSize: 48.0, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ),
          ),
          Row(
            children: <Widget>[
              buildButton("1", Colors.grey[850]!),
              buildButton("2", Colors.grey[850]!),
              buildButton("3", Colors.grey[850]!),
              buildButton("+", Colors.orange),
            ],
          ),
          Row(
            children: <Widget>[
              buildButton("4", Colors.grey[850]!),
              buildButton("5", Colors.grey[850]!),
              buildButton("6", Colors.grey[850]!),
              buildButton("-", Colors.orange),
            ],
          ),
          Row(
            children: <Widget>[
              buildButton("7", Colors.grey[850]!),
              buildButton("8", Colors.grey[850]!),
              buildButton("9", Colors.grey[850]!),
              buildButton("*", Colors.orange),
            ],
          ),
          Row(
            children: <Widget>[
              buildButton("CE", Colors.red),
              buildButton("0", Colors.grey[850]!),
              buildButton("C", Colors.red),
              buildButton("/", Colors.orange),
            ],
          ),
          Row(
            children: <Widget>[
              buildButton("=", Colors.blue),
            ],
          ),
        ],
      ),
    );
  }
}

class HistoryPage extends StatelessWidget {
  final List<String> history;

  HistoryPage({required this.history});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculation History'),
      ),
      body: ListView.builder(
        itemCount: history.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(history[index]),
          );
        },
      ),
    );
  }
}
