package com.example.lab1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
